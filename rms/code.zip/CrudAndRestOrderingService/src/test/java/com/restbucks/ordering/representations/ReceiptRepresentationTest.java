package com.restbucks.ordering.representations;

import com.restbucks.ordering.domain.Money;
import com.restbucks.ordering.domain.Payment;
import org.junit.Test;

import java.util.Calendar;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;


public class ReceiptRepresentationTest
{
    private int nextYear()
    {
        return Calendar.getInstance().get( Calendar.YEAR ) + 1;
    }

    @Test
    public void validReceiptRepresentationsShouldHaveAmountDateAndOrderLink()
    {
        Money money = new Money( 10, 0 );
        ReceiptRepresentation representation =
                new ReceiptRepresentation( new Payment( money, "Joe Strummer", "56565656565", 12, nextYear() ),
                        new Link( Representation.RELATIONS_URI + "order",
                                new RestbucksUri( "http://restbucks.com/order/1234" ), "GET" ) );

        assertEquals( money.toString(), representation.getAmountPaid() );
        assertNotNull( representation.getPaidDate() );
        assertTrue( representation.getPaidDate().isBeforeNow() || representation.getPaidDate().isEqualNow() );
        assertNotNull( representation.getOrderLink() );
    }
}

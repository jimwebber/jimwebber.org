package com.restbucks.ordering.activities;

import com.restbucks.ordering.domain.Identifier;
import com.restbucks.ordering.domain.Money;
import com.restbucks.ordering.domain.Payment;
import com.restbucks.ordering.repositories.PaymentRepository;
import com.restbucks.ordering.representations.ReceiptRepresentation;
import com.restbucks.ordering.representations.RestbucksUri;
import org.junit.Test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

public class ReadReceiptActivityTest
{

    @Test
    public void shouldBeAbleToGenerateAReceiptForAPaidOrder()
    {
        Money money = new Money( 10, 0 );
        Payment payment = new Payment( money, "Nye Bevan", "43534543543", 10, 50 );
        Identifier identifier = PaymentRepository.current().store( payment );

        RestbucksUri receiptUri = new RestbucksUri( "http://restbucks.com/receipt/" + identifier.toString() );
        ReadReceiptActivity activity = new ReadReceiptActivity();
        ReceiptRepresentation representation = activity.read( receiptUri );

        assertEquals( money.toString(), representation.getAmountPaid() );
        assertNotNull( representation.getPaidDate() );
    }

    @Test( expected = OrderNotPaidException.class )
    public void shouldFailToGenerateAReceiptForAnUknowndOrder()
    {
        RestbucksUri receiptUri = new RestbucksUri( "http://restbucks.com/payment/not-paid" );
        ReadReceiptActivity activity = new ReadReceiptActivity();
        activity.read( receiptUri );
    }
}

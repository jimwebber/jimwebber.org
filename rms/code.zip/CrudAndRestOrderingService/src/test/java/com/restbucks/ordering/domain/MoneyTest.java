package com.restbucks.ordering.domain;

import org.junit.Test;

import static org.junit.Assert.assertEquals;

public class MoneyTest
{
    @Test
    public void shouldAcceptStringifiedAmounts() throws Exception
    {
        // given
        Money m1 = new Money( "£2.50" );
        Money m2 = new Money( 2, 50 );

        // then

        assertEquals( m1, m2 );
    }

    @Test( expected = MoneyFormatException.class )
    public void shouldRejectMalformattedStringifiedAmounts() throws Exception
    {
        // given
        Money money = new Money( "£2.5.1" );
    }

    @Test
    public void shouldAddMoney() throws Exception
    {
        // given
        Money m1 = new Money( 10, 10 );
        Money m2 = new Money( 20, 20 );

        // when
        Money result = m1.add( m2 );

        // then
        assertEquals( new Money( 30, 30 ), result );
    }

    @Test
    public void shouldHaveWellFormattedValueForLessThanTenPennies() throws Exception
    {
        // given
        Money money = new Money( 10, 7 );

        // then
        assertEquals( "10.07", money.toString() );
    }
}

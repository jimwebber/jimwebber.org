package com.restbucks.ordering.activities;

import com.restbucks.ordering.domain.Drink;
import com.restbucks.ordering.domain.Identifier;
import com.restbucks.ordering.domain.Item;
import com.restbucks.ordering.domain.Milk;
import com.restbucks.ordering.domain.Money;
import com.restbucks.ordering.domain.Order;
import com.restbucks.ordering.domain.OrderStatus;
import com.restbucks.ordering.domain.Size;
import com.restbucks.ordering.repositories.OrderRepository;
import com.restbucks.ordering.repositories.PaymentRepository;
import com.restbucks.ordering.representations.RestbucksUri;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import static com.restbucks.ordering.domain.OrderBuilder.order;
import static com.restbucks.ordering.domain.PaymentBuilder.payment;
import static org.junit.Assert.assertEquals;


public class PaymentActivityTest
{

    @Before
    @After
    public void clearRepositories()
    {
        PaymentRepository.current().clear();
        OrderRepository.current().clear();
    }

    @Test( expected = NoSuchOrderException.class )
    public void shouldFailForNonExistentOrder()
    {
        PaymentActivity activity = new PaymentActivity();

        RestbucksUri paymentUri = new RestbucksUri( "http://restbucks.com/payment/does-not-exist" );

        activity.pay( payment().build(), paymentUri );
    }

    @Test( expected = InvalidPaymentException.class )
    public void shouldFailForPaidOrder()
    {
        Identifier orderId = placeOrder( OrderStatus.PREPARING );

        PaymentActivity activity = new PaymentActivity();

        RestbucksUri paymentUri = new RestbucksUri( "http://restbucks.com/payment/" + orderId.toString() );

        activity.pay( payment().build(), paymentUri );

    }

    @Test( expected = InvalidPaymentException.class )
    public void shouldFailForPaymentWithTooSmallAnAmount()
    {
        Identifier orderId = placeOrder( OrderStatus.PREPARING );
        Money orderAmount = OrderRepository.current().get( orderId ).calculateCost();

        PaymentActivity activity = new PaymentActivity();

        RestbucksUri paymentUri = new RestbucksUri( "http://restbucks.com/payment/" + orderId.toString() );

        Money wrongfulPaymentAmount = orderAmount.minus( new Money( 0, 19 ) );
        activity.pay( payment().withAmount( wrongfulPaymentAmount ).build(), paymentUri );
    }

    @Test
    public void shouldUpdateOrderStatusOnSuccessfulPayment()
    {
        Identifier orderId = placeOrder( OrderStatus.UNPAID );
        Money orderAmount = OrderRepository.current().get( orderId ).calculateCost();

        PaymentActivity activity = new PaymentActivity();

        RestbucksUri paymentUri = new RestbucksUri( "http://restbucks.com/payment/" + orderId.toString() );

        activity.pay( payment().withAmount( orderAmount ).build(), paymentUri );

        assertEquals( OrderStatus.PREPARING, OrderRepository.current().get( orderId ).getStatus() );

    }

    private Identifier placeOrder( OrderStatus status )
    {
        Order order =
                order().withItem( new Item( Size.LARGE, Milk.SKIM, Drink.CAPPUCCINO ) ).withStatus( status ).build();
        return OrderRepository.current().store( order );
    }
}

package com.restbucks.ordering.domain;

import org.junit.Test;

import java.util.ArrayList;
import java.util.List;

import static org.junit.Assert.assertEquals;


public class OrderTest
{
    @Test
    public void shouldStoreAndRetrieveItems()
    {
        int numberOfItems = 5;
        ArrayList<Item> items = new ArrayList<>();

        for ( int i = 0; i < numberOfItems; i++ )
        {
            items.add( new Item( Size.SMALL, Milk.WHOLE, Drink.LATTE ) );
        }

        Order order = new Order( "Clement Attlee", Location.TAKEAWAY, OrderStatus.UNPAID, items );
        assertEquals( numberOfItems, order.getItems().size() );
    }

    @Test
    public void shouldCalculateCost()
    {
        List<Item> items = new ArrayList<>();
        items.add( new Item( Size.SMALL, Milk.NONE, Drink.ESPRESSO ) );
        items.add( new Item( Size.LARGE, Milk.WHOLE, Drink.LATTE ) );
        items.add( new Item( Size.LARGE, Milk.SEMI, Drink.CAPPUCCINO ) );

        Order order = new Order( "Clement Attlee", Location.TAKEAWAY, OrderStatus.READY, items );
        order.calculateCost();
        assertEquals( new Money( 5, 50 ), order.calculateCost() );
    }
}

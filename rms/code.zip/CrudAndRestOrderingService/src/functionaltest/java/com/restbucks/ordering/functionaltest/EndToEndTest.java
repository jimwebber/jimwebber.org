package com.restbucks.ordering.functionaltest;

import com.restbucks.ordering.domain.Drink;
import com.restbucks.ordering.domain.Identifier;
import com.restbucks.ordering.domain.Item;
import com.restbucks.ordering.domain.Location;
import com.restbucks.ordering.domain.Milk;
import com.restbucks.ordering.domain.Money;
import com.restbucks.ordering.domain.OrderStatus;
import com.restbucks.ordering.domain.Payment;
import com.restbucks.ordering.domain.Size;
import com.restbucks.ordering.repositories.OrderRepository;
import com.restbucks.ordering.representations.Link;
import com.restbucks.ordering.representations.OrderRepresentation;
import com.restbucks.ordering.representations.PaymentRepresentation;
import com.restbucks.ordering.representations.ReceiptRepresentation;
import com.restbucks.ordering.representations.Representation;
import com.restbucks.ordering.representations.RestbucksUri;
import org.glassfish.grizzly.http.server.HttpServer;
import org.glassfish.jersey.grizzly2.httpserver.GrizzlyHttpServerFactory;
import org.glassfish.jersey.server.ResourceConfig;
import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;

import java.net.URI;
import java.util.ArrayList;
import java.util.List;
import javax.ws.rs.client.Client;
import javax.ws.rs.client.Invocation;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import static com.restbucks.ordering.domain.ItemBuilder.item;
import static com.restbucks.ordering.representations.Representation.RESTBUCKS_MEDIA_TYPE;
import static javax.ws.rs.client.ClientBuilder.newClient;
import static javax.ws.rs.client.Entity.entity;
import static org.hamcrest.Matchers.containsString;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertThat;
import static org.junit.Assert.assertTrue;

public class EndToEndTest
{
    private static final String BASE_URI = "http://localhost:9090/";
    private static HttpServer server;

    @BeforeClass
    public static void startService()
    {
        server = GrizzlyHttpServerFactory
                .createHttpServer( URI.create( BASE_URI ), new ResourceConfig().packages( "com.restbucks" ) );
    }

    @AfterClass
    public static void stopService()
    {
        server.shutdownNow();
    }

    @Test
    public void shouldHaveAWellKnownEntryPointAtRoot() throws Exception
    {
        // given
        Client client = newClient();
        WebTarget target = client.target( BASE_URI );
        Invocation.Builder builder = target.request( MediaType.TEXT_HTML );

        // when
        Response response = builder.get();

        // then
        assertEquals( 200, response.getStatus() );
        assertTrue( response.hasEntity() );

        String entityBody = response.readEntity( String.class );
        assertThat( entityBody, containsString( "<html>" ) );
        assertThat( entityBody, containsString( "Welcome to Restbucks" ) );
    }

    @Test
    public void shouldNotAcceptMalformattedOrders()
    {
        Client client = newClient();
        WebTarget target = client.target( BASE_URI + "order" );
        Invocation.Builder builder = target.request( RESTBUCKS_MEDIA_TYPE );

        Response response = builder.post( entity( "[1, 2, 3, 4, 5, 6, 7, 8, 9, 10]", RESTBUCKS_MEDIA_TYPE ) );

        assertEquals( 400, response.getStatus() );
    }

    @Test
    public void shouldBeAbleToPlaceAnOrder()
    {
        Client client = newClient();
        WebTarget target = client.target( BASE_URI + "order" );

        Item item = new Item( Size.LARGE, Milk.SEMI, Drink.CAPPUCCINO );
        List<Item> items = new ArrayList<>();
        items.add( item );

        CustomerOrder order = new CustomerOrder( "Nye Bevan", Location.TAKEAWAY, items );

        Invocation.Builder builder = target.request( RESTBUCKS_MEDIA_TYPE );
        Response response = builder.accept( RESTBUCKS_MEDIA_TYPE ).post( entity( order, RESTBUCKS_MEDIA_TYPE ) );

        assertEquals( 201, response.getStatus() );
        assertNotNull( response.getLocation() );
        OrderRepresentation responseRepresentation = response.readEntity( OrderRepresentation.class );
        assertNotNull( responseRepresentation );

        assertNotNull( responseRepresentation.getCancelLink() );
        assertNotNull( responseRepresentation.getPaymentLink() );
        assertNotNull( responseRepresentation.getUpdateLink() );
        assertNotNull( responseRepresentation.getSelfLink() );

        assertTrue( responseRepresentation.getOrder().calculateCost().inPence() > 0 );

        assertThat( responseRepresentation.toString(), containsString( "status>" ) );
        assertThat( responseRepresentation.toString(), containsString( "cost>" ) );

    }

    @Test
    public void shouldBeAbleToPlaceAndReadAnOrder()
    {
        OrderRepresentation placedOrder = placeOrder();

        Client client = newClient();
        WebTarget target = client.target( placedOrder.getSelfLink().getUri() );

        Invocation.Builder builder = target.request( RESTBUCKS_MEDIA_TYPE );
        Response response = builder.accept( RESTBUCKS_MEDIA_TYPE ).get();
        OrderRepresentation responseRepresentation = response.readEntity( OrderRepresentation.class );

        assertEquals( 200, response.getStatus() );
        assertNotNull( responseRepresentation );
        assertNotNull( responseRepresentation.getCancelLink() );
        assertNotNull( responseRepresentation.getPaymentLink() );
        assertNotNull( responseRepresentation.getUpdateLink() );
        assertNotNull( responseRepresentation.getSelfLink() );
    }


    @Test
    public void shouldBeAbleToCancelAnOrderOnceOnly()
    {
        OrderRepresentation placedOrder = placeOrder();
        Client client = newClient();
        WebTarget target = client.target( placedOrder.getCancelLink().getUri() );

        Invocation.Builder builder = target.request( RESTBUCKS_MEDIA_TYPE );
        Response response = builder.accept( RESTBUCKS_MEDIA_TYPE ).delete();

        assertEquals( 200, response.getStatus() );

        response = builder.accept( RESTBUCKS_MEDIA_TYPE ).delete();
        assertEquals( 404, response.getStatus() );
    }

    @Test
    public void shouldBeAbleToUpdateAnOrderAnyNumberOfTimesBeforeCancellingAndNotAfterwards()
    {
        RestbucksUri orderUri = new RestbucksUri( placeOrder().getUpdateLink().getUri() );

        int reasonableNumberOfUpdates = 10;
        Response response = null;
        for ( int i = 0; i < reasonableNumberOfUpdates; i++ )
        {
            CustomerOrder order = createRandomOrder();

            response = updateOrder( orderUri, order );

            assertEquals( 200, response.getStatus() );
        }

        OrderRepresentation lastSuccessfullyPlacedOrderRepresentation =
                response.readEntity( OrderRepresentation.class );

        OrderRepresentation cancelledOrder = cancelOrder( lastSuccessfullyPlacedOrderRepresentation.getCancelLink() );
        assertNull( cancelledOrder.getCancelLink() );
        assertNull( cancelledOrder.getPaymentLink() );
        assertNull( cancelledOrder.getUpdateLink() );

        response = updateOrder( new RestbucksUri( lastSuccessfullyPlacedOrderRepresentation.getUpdateLink().getUri() ),
                new CustomerOrder( lastSuccessfullyPlacedOrderRepresentation.getOrder() ) );
        assertEquals( 404, response.getStatus() );
    }


    @Test
    public void shouldBeAbleToPlaceAndPayForAnOrderOnceOnly()
    {
        OrderRepresentation orderRepresentation = placeOrder();

        Client client = newClient();
        WebTarget target = client.target( orderRepresentation.getPaymentLink().getUri() );

        Invocation.Builder builder = target.request( RESTBUCKS_MEDIA_TYPE );

        Response response = builder.accept( RESTBUCKS_MEDIA_TYPE )
                .put( entity( createPayment( orderRepresentation.getOrder().calculateCost() ),
                        MediaType.valueOf( RESTBUCKS_MEDIA_TYPE ) ) );

        assertEquals( 201, response.getStatus() );

        response = builder.accept( RESTBUCKS_MEDIA_TYPE )
                .put( entity( createPayment( orderRepresentation.getOrder().calculateCost() ),
                        MediaType.valueOf( RESTBUCKS_MEDIA_TYPE ) ) );

        assertNull( response.getMetadata().get( "Allow" ) );
        assertEquals( 403, response.getStatus() );
        Link orderLink = response.readEntity( Link.class );
        assertThat( orderLink.getRelValue(), containsString( Representation.SELF_REL_VALUE ) );
        assertThat( orderLink.getUri().toString(), containsString( "/order/" ) );
    }

    @Test
    public void shouldBeAbleToOrderPayAndGetReceiptThenWaitForOrderCompletion()
    {
        OrderRepresentation orderRepresentation = placeOrder();

        PaymentRepresentation paymentRepresentation = payForOrder( orderRepresentation );

        assertNotNull( paymentRepresentation );

        assertEquals( orderRepresentation.getSelfLink().getUri(), paymentRepresentation.getOrderLink().getUri() );
        URI receiptUri = paymentRepresentation.getReceiptLink().getUri();
        assertNotNull( receiptUri );

        Client receiptClient = newClient();
        WebTarget receiptResource = receiptClient.target( receiptUri );

        ReceiptRepresentation receiptRepresentation =
                receiptResource.request( RESTBUCKS_MEDIA_TYPE ).get( ReceiptRepresentation.class );

        assertNotNull( receiptRepresentation.getPaidDate() );
        URI orderUri = receiptRepresentation.getOrderLink().getUri();
        assertNotNull( orderUri );

        // Poll the order until it becomes READY
        Client orderClient = newClient();
        WebTarget polledOrderResource = orderClient.target( orderUri );
        OrderRepresentation polledRepresentation =
                polledOrderResource.request( RESTBUCKS_MEDIA_TYPE ).get( OrderRepresentation.class );

        assertEquals( OrderStatus.PREPARING, polledRepresentation.getOrder().getStatus() );

        URI polledOrderUri = polledRepresentation.getSelfLink().getUri();
        while ( polledRepresentation.getOrder().getStatus() != OrderStatus.READY )
        {
            polledRepresentation = polledOrderResource.request( RESTBUCKS_MEDIA_TYPE ).accept( RESTBUCKS_MEDIA_TYPE )
                    .get( OrderRepresentation.class );
            pokeTheBarista( polledOrderUri );
        }

        // Finally take the order
        Response receiptResponse = receiptResource.request( RESTBUCKS_MEDIA_TYPE ).delete();
        assertEquals( 200, receiptResponse.getStatus() );

        OrderRepresentation finalOrderRepresentation = receiptResponse.readEntity( OrderRepresentation.class );
        assertNotNull( finalOrderRepresentation );
        assertNotNull( finalOrderRepresentation.getOrder() );
        assertNull( finalOrderRepresentation.getCancelLink() );
        assertNull( finalOrderRepresentation.getSelfLink() );
        assertNull( finalOrderRepresentation.getUpdateLink() );
        assertNull( finalOrderRepresentation.getPaymentLink() );

        //Make sure receipt is still around, but without hyperlinks
        receiptResource = receiptClient.target( receiptUri );
        receiptResponse = receiptResource.request( RESTBUCKS_MEDIA_TYPE ).get();
        assertEquals( 204, receiptResponse.getStatus() );
    }

    @Test
    public void shouldNotBeAbleToCancelPaidOrder()
    {
        OrderRepresentation orderRepresentation = placeOrder();
        payforOrder( orderRepresentation );

        Client client = newClient();
        WebTarget orderResource = client.target( orderRepresentation.getCancelLink().getUri() );
        Response response = orderResource.request( RESTBUCKS_MEDIA_TYPE ).accept( RESTBUCKS_MEDIA_TYPE ).delete();

        assertEquals( 405, response.getStatus() );
        List<Object> allowedVerbs = response.getMetadata().get( "Allow" );
        assertNotNull( allowedVerbs );
        assertEquals( 1, allowedVerbs.size() );
    }


    @Test
    public void shouldBeAbleToObtainTheRepresentationOfARecentlyPlacedOrder()
    {
        RestbucksUri orderUri = new RestbucksUri( placeOrder().getUpdateLink().getUri() );

        Client client = newClient();
        WebTarget orderResource = client.target( orderUri.getFullUri() );

        Response response = orderResource.request( RESTBUCKS_MEDIA_TYPE ).accept( RESTBUCKS_MEDIA_TYPE ).get();

        assertEquals( 200, response.getStatus() );
        OrderRepresentation responseRepresentation = response.readEntity( OrderRepresentation.class );
        assertNotNull( responseRepresentation );
    }

    private PaymentRepresentation payForOrder( OrderRepresentation orderRepresentation )
    {
        Client client = newClient();

        WebTarget target = client.target( orderRepresentation.getPaymentLink().getUri() );
        Invocation.Builder builder = target.request( RESTBUCKS_MEDIA_TYPE );

        Response response = builder.accept( RESTBUCKS_MEDIA_TYPE )
                .put( entity( createPayment( orderRepresentation.getOrder().calculateCost() ),
                        MediaType.valueOf( RESTBUCKS_MEDIA_TYPE ) ) );

        return response.readEntity( PaymentRepresentation.class );
    }

    private void payforOrder( OrderRepresentation orderRepresentation )
    {
        Client client = newClient();
        WebTarget target = client.target( orderRepresentation.getPaymentLink().getUri() );
        Invocation.Builder builder = target.request( RESTBUCKS_MEDIA_TYPE );

        builder.accept( RESTBUCKS_MEDIA_TYPE )
                .put( entity( createPayment( orderRepresentation.getOrder().calculateCost() ),
                        MediaType.valueOf( RESTBUCKS_MEDIA_TYPE ) ) );
    }

    private CustomerPayment createPayment( Money cost )
    {
        return new CustomerPayment( new Payment( cost, "Michael Farraday", "11223344", 12, 12 ) );
    }

    private OrderRepresentation cancelOrder( Link cancelLink )
    {
        Client client = newClient();
        WebTarget target = client.target( cancelLink.getUri().toString() );
        Invocation.Builder builder = target.request( RESTBUCKS_MEDIA_TYPE );

        return builder.accept( RESTBUCKS_MEDIA_TYPE ).delete( OrderRepresentation.class );
    }

    private Response updateOrder( RestbucksUri orderUri, CustomerOrder order )
    {
        Client client = newClient();
        WebTarget target = client.target( orderUri.toString() );
        Invocation.Builder builder = target.request( RESTBUCKS_MEDIA_TYPE );

        return builder.accept( RESTBUCKS_MEDIA_TYPE ).post( entity( order, RESTBUCKS_MEDIA_TYPE ) );
    }


    private CustomerOrder createRandomOrder()
    {
        int numberOfItemsInOrder = (int) (System.currentTimeMillis() % 10) + 1; // Always at least one!
        List<Item> items = new ArrayList<>();

        for ( int i = 0; i < numberOfItemsInOrder; i++ )
        {
            items.add( item().random().build() );
        }

        return new CustomerOrder( "Nye Bevan", Location.IN_STORE, items );
    }

    private OrderRepresentation placeOrder()
    {
        Client client = newClient();
        WebTarget target = client.target( BASE_URI + "order" );
        Invocation.Builder builder = target.request( RESTBUCKS_MEDIA_TYPE );

        Item item = new Item( Size.LARGE, Milk.SEMI, Drink.CAPPUCCINO );
        List<Item> items = new ArrayList<>();
        items.add( item );

        CustomerOrder customerOrder = new CustomerOrder( "Nye Bevan", Location.TAKEAWAY, items );

        return builder.post( entity( customerOrder, RESTBUCKS_MEDIA_TYPE ) ).readEntity( OrderRepresentation.class );
    }

    private void pokeTheBarista( URI orderUri )
    {
        Identifier identifier = new RestbucksUri( orderUri ).getId();
        OrderRepository.current().get( identifier ).setStatus( OrderStatus.READY );
    }
}

package com.restbucks.ordering.activities;

import com.restbucks.ordering.domain.Money;

import static java.lang.String.format;

public class InvalidPaymentException extends RuntimeException
{
    private static final long serialVersionUID = -9208425088487285282L;

    InvalidPaymentException( Money actualCost, Money receivedPayment )
    {
        super( format( "Order total: %s, Payment recieved: %s", actualCost.toString(), receivedPayment.toString() ) );
    }
}

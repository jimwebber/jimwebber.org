package com.restbucks.ordering.domain;

import java.util.Objects;

import static java.lang.String.format;

public class Money
{
    private int pennies;

    public Money( int pounds, int pence )
    {
        if ( pence < 0 || pence > 99 )
        {
            throw new MoneyFormatException( format( "Pence must be between 0 and +99, %d is not acceptable.", pence ) );
        }

        pennies = pounds * 100 + pence;
    }

    public Money( String money )
    {
        String[] poundsAndPence = money.replaceAll( "[^\\d.]+", "" ).split( "\\." );

        if ( poundsAndPence.length != 2 )
        {
            throw new MoneyFormatException(
                    format( "Cannot parse argument [%s], correct format uses pound sign and single dot, for example: £2.99",
                            money ) );
        }

        pennies = 100 * Integer.valueOf( poundsAndPence[0] ) + Integer.valueOf( poundsAndPence[1] );
    }

    public Money()
    {
        this( 0, 0 );
    }

    private Money( int penceOnly )
    {
        this.pennies = penceOnly;
    }

    public int inPence()
    {
        return pennies;
    }

    public Money add( Money money )
    {
        return new Money( this.pennies + money.pennies );
    }

    public Money minus( Money money )
    {
        return new Money( this.pennies - money.pennies );
    }


    @Override
    public String toString()
    {
        int pounds = pennies / 100;
        int pence = pennies % 100;

        StringBuilder sb = new StringBuilder();
        sb.append( pounds );
        sb.append( "." );

        if ( pence < 10 )
        {
            sb.append( "0" );
        }

        sb.append( pence );
        return sb.toString();
    }

    @Override
    public boolean equals( Object o )
    {
        if ( this == o )
        {
            return true;
        }
        if ( o == null || getClass() != o.getClass() )
        {
            return false;
        }
        Money money = (Money) o;
        return pennies == money.pennies;
    }

    @Override
    public int hashCode()
    {
        return Objects.hash( pennies );
    }

}

package com.restbucks.ordering.activities;

public class NoSuchOrderException extends RuntimeException
{

    private static final long serialVersionUID = -1965920604455766371L;

}

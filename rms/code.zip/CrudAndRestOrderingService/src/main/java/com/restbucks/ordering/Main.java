package com.restbucks.ordering;

import org.glassfish.grizzly.http.server.HttpServer;
import org.glassfish.jersey.grizzly2.httpserver.GrizzlyHttpServerFactory;
import org.glassfish.jersey.server.ResourceConfig;

import java.io.IOException;
import java.net.URI;

public class Main
{

    private static HttpServer server;

    public static void main( String[] args ) throws IOException
    {

        final String baseUri = "http://0.0.0.0:8080/";

        System.out.println( "Starting Restbucks..." );
        startService( baseUri );
        System.out.println( "Restbucks started." );
        System.in.read();
        stopService();
        System.exit( 0 );
    }

    private static void startService( String baseUri )
    {
        server = GrizzlyHttpServerFactory
                .createHttpServer( URI.create( baseUri ), new ResourceConfig().packages( "com.restbucks" ) );
    }

    private static void stopService()
    {
        server.shutdownNow();
    }
}

package com.restbucks.ordering.representations;

import com.restbucks.ordering.domain.Money;
import com.restbucks.ordering.domain.Payment;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;


@XmlRootElement( name = "payment", namespace = Representation.RESTBUCKS_NAMESPACE )
public class PaymentRepresentation extends Representation
{

    @XmlElement( namespace = PaymentRepresentation.RESTBUCKS_NAMESPACE )
    private String amount;
    @XmlElement( namespace = PaymentRepresentation.RESTBUCKS_NAMESPACE )
    private String cardholderName;
    @XmlElement( namespace = PaymentRepresentation.RESTBUCKS_NAMESPACE )
    private String cardNumber;
    @XmlElement( namespace = PaymentRepresentation.RESTBUCKS_NAMESPACE )
    private int expiryMonth;
    @XmlElement( namespace = PaymentRepresentation.RESTBUCKS_NAMESPACE )
    private int expiryYear;

    /**
     * For JAXB :-(
     */
    PaymentRepresentation()
    {
    }

    public PaymentRepresentation( Payment payment, Link... links )
    {
        amount = payment.getAmount().toString();
        cardholderName = payment.getCardholderName();
        cardNumber = payment.getCardNumber();
        expiryMonth = payment.getExpiryMonth();
        expiryYear = payment.getExpiryYear();
        this.links = java.util.Arrays.asList( links );
    }

    public Payment getPayment()
    {
        return new Payment( new Money( amount ), cardholderName, cardNumber, expiryMonth, expiryYear );
    }

    public Link getReceiptLink()
    {
        return getLinkByName( Representation.RELATIONS_URI + "receipt" );
    }

    public Link getOrderLink()
    {
        return getLinkByName( Representation.RELATIONS_URI + "order" );
    }
}

package com.restbucks.ordering.activities;

public class OrderAlreadyCompletedException extends RuntimeException
{
    private static final long serialVersionUID = 3262756650707370012L;
}

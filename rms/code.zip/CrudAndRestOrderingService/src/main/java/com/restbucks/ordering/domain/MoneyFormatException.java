package com.restbucks.ordering.domain;

public class MoneyFormatException extends RuntimeException
{
    MoneyFormatException( String message )
    {
        super( message );
    }
}

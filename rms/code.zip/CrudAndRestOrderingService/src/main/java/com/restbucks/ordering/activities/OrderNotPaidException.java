package com.restbucks.ordering.activities;

public class OrderNotPaidException extends RuntimeException
{
    private static final long serialVersionUID = 1543107470867581744L;

}

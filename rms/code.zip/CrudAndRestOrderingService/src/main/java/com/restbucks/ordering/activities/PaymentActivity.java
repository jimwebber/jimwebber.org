package com.restbucks.ordering.activities;

import com.restbucks.ordering.domain.Identifier;
import com.restbucks.ordering.domain.OrderStatus;
import com.restbucks.ordering.domain.Payment;
import com.restbucks.ordering.repositories.OrderRepository;
import com.restbucks.ordering.repositories.PaymentRepository;
import com.restbucks.ordering.representations.Link;
import com.restbucks.ordering.representations.PaymentRepresentation;
import com.restbucks.ordering.representations.Representation;
import com.restbucks.ordering.representations.RestbucksUri;

public class PaymentActivity
{
    public PaymentRepresentation pay( Payment payment, RestbucksUri paymentUri )
    {
        Identifier identifier = paymentUri.getId();

        // Don't know the order!
        if ( !OrderRepository.current().has( identifier ) )
        {
            throw new NoSuchOrderException();
        }

        // Already paid
        if ( PaymentRepository.current().has( identifier ) )
        {
            throw new UpdateException();
        }

        // Business rules - payment must match or be greater than the demanded amount (allows for tips)
        if ( OrderRepository.current().get( identifier ).calculateCost().inPence() > payment.getAmount().inPence() )
        {
            throw new InvalidPaymentException( OrderRepository.current().get( identifier ).calculateCost(),
                    payment.getAmount() );
        }

        // If we get here, let's create the payment and update the order status
        OrderRepository.current().get( identifier ).setStatus( OrderStatus.PREPARING );
        PaymentRepository.current().store( identifier, payment );

        return new PaymentRepresentation( payment,
                new Link( Representation.RELATIONS_URI + "order", UriExchange.orderForPayment( paymentUri ) ),
                new Link( Representation.RELATIONS_URI + "receipt", UriExchange.receiptForPayment( paymentUri ) ) );
    }
}

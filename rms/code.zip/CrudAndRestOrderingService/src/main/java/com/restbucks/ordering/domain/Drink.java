package com.restbucks.ordering.domain;

import javax.xml.bind.annotation.XmlEnumValue;

public enum Drink
{
    @XmlEnumValue( value = "espresso" )
    ESPRESSO( 1, 50 ),
    @XmlEnumValue( value = "latte" )
    LATTE( 2, 0 ),
    @XmlEnumValue( value = "cappuccino" )
    CAPPUCCINO( 2, 0 ),
    @XmlEnumValue( value = "americano" )
    AMERICANO( 1, 80 );

    // price support
    final Money price;

    Drink( Money price )
    {
        this.price = price;
    }


    Drink( int pounds, int pence )
    {
        price = new Money( pounds, pence );
    }

    public Money getPrice()
    {
        return this.price;
    }
}

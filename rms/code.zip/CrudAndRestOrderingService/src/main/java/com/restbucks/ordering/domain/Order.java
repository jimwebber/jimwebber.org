package com.restbucks.ordering.domain;

import com.restbucks.ordering.activities.InvalidOrderException;

import java.util.List;
import javax.xml.bind.annotation.XmlTransient;

public class Order
{
    private final Location location;
    private final List<Item> items;
    private String name;
    @XmlTransient
    private OrderStatus status = OrderStatus.UNPAID;

    public Order( String name, Location location, OrderStatus status, List<Item> items )
    {
        if ( name == null || location == null || status == null || items == null || items.size() == 0 )
        {
            throw new InvalidOrderException( "Order arguments cannot be null" );
        }

        this.name = name;
        this.location = location;
        this.items = items;
        this.status = status;
    }

    public String getCustomerName()
    {
        return name;
    }
    public Location getLocation()
    {
        return location;
    }

    public List<Item> getItems()
    {
        return items;
    }

    public Money calculateCost()
    {
        Money total = new Money();
        if ( items != null )
        {
            for ( Item item : items )
            {
                if ( item != null && item.getDrink() != null )
                {
                    total = total.add( item.getDrink().getPrice() );
                }
            }
        }
        return total;
    }

    public OrderStatus getStatus()
    {
        return status;
    }

    public void setStatus( OrderStatus status )
    {
        this.status = status;
    }

    public String toString()
    {
        StringBuilder sb = new StringBuilder();
        sb.append( "Name: " ).append( name ).append( "\n" );
        sb.append( "Location: " ).append( location ).append( "\n" ).append( "Status: " ).append( status )
                .append( "\n" );
        for ( Item i : items )
        {
            sb.append( "Item: " ).append( i.toString() ).append( "\n" );
        }
        return sb.toString();
    }
}

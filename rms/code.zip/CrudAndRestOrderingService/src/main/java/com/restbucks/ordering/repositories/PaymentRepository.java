package com.restbucks.ordering.repositories;

import com.restbucks.ordering.domain.Identifier;
import com.restbucks.ordering.domain.Payment;

import java.util.HashMap;
import java.util.Map.Entry;

public class PaymentRepository
{

    private static final PaymentRepository theRepository = new PaymentRepository();
    private HashMap<String,Payment> backingStore = new HashMap<>();
            // Default implementation, not suitable for production!

    private PaymentRepository()
    {
    }

    public static PaymentRepository current()
    {
        return theRepository;
    }

    public Payment get( Identifier identifier )
    {
        return backingStore.get( identifier.toString() );
    }

    public Payment take( Identifier identifier )
    {
        return backingStore.remove( identifier.toString() );
    }

    public Identifier store( Payment payment )
    {
        Identifier id = new Identifier();
        backingStore.put( id.toString(), payment );
        return id;
    }

    public void store( Identifier paymentIdentifier, Payment payment )
    {
        backingStore.put( paymentIdentifier.toString(), payment );
    }

    public boolean has( Identifier identifier )
    {
        return backingStore.containsKey( identifier.toString() );
    }

    public void remove( Identifier identifier )
    {
        backingStore.remove( identifier.toString() );
    }

    public String toString()
    {
        StringBuilder sb = new StringBuilder();
        for ( Entry<String,Payment> entry : backingStore.entrySet() )
        {
            sb.append( entry.getKey() );
            sb.append( "\t:\t" );
            sb.append( entry.getValue() );
            sb.append( "\n" );
        }
        return sb.toString();
    }

    public synchronized void clear()
    {
        backingStore = new HashMap<>();
    }
}

package com.restbucks.ordering.representations;

import com.restbucks.ordering.domain.Payment;
import org.joda.time.DateTime;

import java.io.StringWriter;
import java.util.ArrayList;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.Marshaller;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement( name = "receipt", namespace = Representation.RESTBUCKS_NAMESPACE )
public class ReceiptRepresentation extends Representation
{

    @XmlElement( name = "amount", namespace = Representation.RESTBUCKS_NAMESPACE )
    private String amountPaid;
    @XmlElement( name = "paid", namespace = Representation.RESTBUCKS_NAMESPACE )
    private String paymentDate;

    ReceiptRepresentation()
    {
    } // For JAXB :-(

    public ReceiptRepresentation( Payment payment, Link orderLink )
    {
        this.amountPaid = payment.getAmount().toString();
        this.paymentDate = payment.getPaymentDate().toString();
        this.links = new ArrayList<>();
        links.add( orderLink );
    }

    public DateTime getPaidDate()
    {
        return new DateTime( paymentDate );
    }

    public String getAmountPaid()
    {
        return amountPaid;
    }

    public Link getOrderLink()
    {
        return getLinkByName( Representation.RELATIONS_URI + "order" );
    }

    public String toString()
    {
        try
        {
            JAXBContext context = JAXBContext.newInstance( ReceiptRepresentation.class );
            Marshaller marshaller = context.createMarshaller();

            StringWriter stringWriter = new StringWriter();
            marshaller.marshal( this, stringWriter );

            return stringWriter.toString();
        }
        catch ( Exception e )
        {
            throw new RuntimeException( e );
        }
    }
}

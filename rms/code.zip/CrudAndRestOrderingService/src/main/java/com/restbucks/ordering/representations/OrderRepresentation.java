package com.restbucks.ordering.representations;

import com.restbucks.ordering.activities.InvalidOrderException;
import com.restbucks.ordering.activities.UriExchange;
import com.restbucks.ordering.domain.Item;
import com.restbucks.ordering.domain.Location;
import com.restbucks.ordering.domain.Order;
import com.restbucks.ordering.domain.OrderStatus;

import java.io.ByteArrayInputStream;
import java.io.StringWriter;
import java.util.List;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.Marshaller;
import javax.xml.bind.Unmarshaller;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement( name = "order", namespace = Representation.RESTBUCKS_NAMESPACE )
public class OrderRepresentation extends Representation
{

    @XmlElement( name = "name", namespace = Representation.RESTBUCKS_NAMESPACE )
    private String customerName;
    @XmlElement( name = "item", namespace = Representation.RESTBUCKS_NAMESPACE )
    private List<Item> items;
    @XmlElement( name = "location", namespace = Representation.RESTBUCKS_NAMESPACE )
    private Location location;
    @XmlElement( name = "cost", namespace = Representation.RESTBUCKS_NAMESPACE, required = true )
    private String cost;
    @XmlElement( name = "status", namespace = Representation.RESTBUCKS_NAMESPACE )
    private OrderStatus status;

    /**
     * For JAXB :-(
     */
    OrderRepresentation()
    {
    }

    public OrderRepresentation( Order order, Link... links )
    {
        try
        {
            this.customerName = order.getCustomerName();
            this.location = order.getLocation();
            this.items = order.getItems();
            this.cost = order.calculateCost().toString();
            this.status = order.getStatus();
            this.links = java.util.Arrays.asList( links );
        }
        catch ( Exception ex )
        {
            throw new InvalidOrderException( ex );
        }
    }

    public static OrderRepresentation fromXmlString( String xmlRepresentation )
    {
        try
        {
            JAXBContext context = JAXBContext.newInstance( OrderRepresentation.class );
            Unmarshaller unmarshaller = context.createUnmarshaller();
            return (OrderRepresentation) unmarshaller
                    .unmarshal( new ByteArrayInputStream( xmlRepresentation.getBytes() ) );
        }
        catch ( Exception e )
        {
            throw new InvalidOrderException( e );
        }
    }

    public static OrderRepresentation createResponseOrderRepresentation( Order order, RestbucksUri orderUri )
    {
        RestbucksUri paymentUri = new RestbucksUri( orderUri.getBaseUri() + "/payment/" + orderUri.getId().toString() );
        if ( order.getStatus() == OrderStatus.UNPAID )
        {
            return new OrderRepresentation( order, new Link( RELATIONS_URI + "cancel", orderUri ),
                    new Link( RELATIONS_URI + "payment", paymentUri ), new Link( RELATIONS_URI + "update", orderUri ),
                    new Link( Representation.SELF_REL_VALUE, orderUri ) );
        }
        else if ( order.getStatus() == OrderStatus.PREPARING )
        {
            OrderRepresentation orderRepresentation = new OrderRepresentation( order, new Link( Representation.SELF_REL_VALUE, orderUri ) );
            order.setStatus( OrderStatus.READY );
            return orderRepresentation;
        }
        else if ( order.getStatus() == OrderStatus.READY )
        {
            return new OrderRepresentation( order,
                    new Link( Representation.RELATIONS_URI + "receipt", UriExchange.receiptForPayment( paymentUri ) ) );
        }
        else if ( order.getStatus() == OrderStatus.TAKEN )
        {
            return new OrderRepresentation( order );
        }
        else
        {
            throw new RuntimeException( "Unknown Order Status" );
        }
    }

    public String toString()
    {
        try
        {
            JAXBContext context = JAXBContext.newInstance( OrderRepresentation.class );
            Marshaller marshaller = context.createMarshaller();
            marshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);

            StringWriter stringWriter = new StringWriter();
            marshaller.marshal( this, stringWriter );

            return stringWriter.toString();
        }
        catch ( Exception e )
        {
            throw new RuntimeException( e );
        }
    }

    public Order getOrder()
    {
        if(status == null) {
            status = OrderStatus.PREPARING;
        }

        return new Order( customerName, location, status, items );
    }

    public Link getCancelLink()
    {
        return getLinkByName( RELATIONS_URI + "cancel" );
    }

    public Link getPaymentLink()
    {
        return getLinkByName( RELATIONS_URI + "payment" );
    }

    public Link getUpdateLink()
    {
        return getLinkByName( RELATIONS_URI + "update" );
    }

    public Link getSelfLink()
    {
        return getLinkByName( "self" );
    }

    public OrderStatus getStatus()
    {
        return status;
    }
}

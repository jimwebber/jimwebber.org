package com.restbucks.ordering.activities;

public class OrderDeletionException extends RuntimeException
{

    private static final long serialVersionUID = -483640022013409026L;

}
